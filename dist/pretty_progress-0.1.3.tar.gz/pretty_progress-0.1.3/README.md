# pretty_progress

A simple Python progress bar utility for loops.

## Installation

```
pip install pretty_progress
```

## Usage

```python
from pretty_progress import progress_bar

for i in range(100):
    progress_bar(i, 100)
```
